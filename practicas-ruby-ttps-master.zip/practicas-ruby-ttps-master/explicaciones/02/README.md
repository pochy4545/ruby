# TTPS opción Ruby

# Explicación de Práctica 2

En esta explicación veremos el uso de módulos como _Mixins_. Para probar y seguir la explicación, podés abrir el archivo
`mixins.rb` de este mismo directorio y a partir de éste ver la implementación y documentación que hemos armado para
documentar esta técnica de implementación de herencia horizontal en Ruby.

## Cómo probarlo

Con una shell ubicada en el mismo directorio que está este `README`, ejecutá el script `mixins.rb`:

```console
$ ruby mixins.rb
```
