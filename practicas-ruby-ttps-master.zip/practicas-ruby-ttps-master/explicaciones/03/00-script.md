# Excepciones

* `raise`
  * `replica.rb`
* `throw`
  * `throw.rb`
* `else`
  * `else.rb`

# Testing

* MiniTest
  * Tradicional
  * Spec
